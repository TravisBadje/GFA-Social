import { useState } from "react";

const mockPosts = [
  { user: "ShadowFist", text: "Готов к следующему бою 💀 #FightNight" },
  { user: "DeadBlade", text: "Ищу спарринг на выходные, кто в деле?" },
];

export default function Home() {
  const [posts, setPosts] = useState(mockPosts);
  const [newPost, setNewPost] = useState("");

  const handlePost = () => {
    if (newPost.trim() !== "") {
      setPosts([{ user: "Ты", text: newPost }, ...posts]);
      setNewPost("");
    }
  };

  return (
    <div className="min-h-screen bg-black text-white p-4">
      <h1 className="text-2xl font-bold mb-4">GFA Социальная Сеть</h1>

      <div className="mb-6">
        <textarea
          placeholder="Что у тебя на уме, боец?.."
          value={newPost}
          onChange={(e) => setNewPost(e.target.value)}
          className="w-full p-2 bg-gray-800 text-white rounded"
        />
        <button
          onClick={handlePost}
          className="mt-2 bg-white text-black px-4 py-1 rounded"
        >
          Опубликовать
        </button>
      </div>

      <div className="space-y-4">
        {posts.map((post, index) => (
          <div key={index} className="bg-gray-900 p-4 rounded">
            <p className="text-sm text-gray-400">{post.user}</p>
            <p className="mt-1 text-white">{post.text}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
